DROP TABLE IF EXISTS `#__package`;
DROP TABLE IF EXISTS `#__wms_information`;
DROP TABLE IF EXISTS `#__package_detail`;
DROP TABLE IF EXISTS `#__package_detail_sub`;
DROP TABLE IF EXISTS `#__package_name`;